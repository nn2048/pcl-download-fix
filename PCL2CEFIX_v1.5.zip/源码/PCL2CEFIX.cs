// PCL2CEFIX —— PCL2-CE 区域限制解锁工具
// 目标：PCL.RestrictedFeaturePolicy.Check(feature, showHint) 永远返回 true
//
// CE 是 .NET 单文件自包含程序（x64 原生宿主 + 内嵌未压缩的托管程序集），
// 所以这里不重打包：直接把内嵌程序集里那段 16 字节的判定改写成“直接 return true”。
using System;
using System.Collections.Generic;
using System.IO;
using System.Security.Cryptography;
using System.Text;

internal sealed class Pe
{
    public byte[] D;
    public int PeOff, NSec, OptSize, OptOff, SecOff;
    public uint U32(int o) { return (uint)(D[o] | D[o + 1] << 8 | D[o + 2] << 16 | D[o + 3] << 24); }
    public int I32(int o) { return (int)U32(o); }
    public ushort U16(int o) { return (ushort)(D[o] | D[o + 1] << 8); }
    public void W32(int o, uint v) { D[o] = (byte)v; D[o + 1] = (byte)(v >> 8); D[o + 2] = (byte)(v >> 16); D[o + 3] = (byte)(v >> 24); }

    public Pe(byte[] d)
    {
        D = d;
        if (D.Length < 0x100 || D[0] != 'M' || D[1] != 'Z') throw new Exception("不是 PE 文件");
        PeOff = I32(0x3c);
        if (PeOff <= 0 || PeOff + 24 > D.Length || D[PeOff] != 'P' || D[PeOff + 1] != 'E') throw new Exception("PE 头无效");
        NSec = U16(PeOff + 6);
        OptSize = U16(PeOff + 20);
        OptOff = PeOff + 24;
        SecOff = OptOff + OptSize;
    }

    public int Opt(int rel) { return OptOff + rel; }
    public int SecHdr(int i) { return SecOff + i * 40; }

    public int RvaToOff(int rva)
    {
        for (int i = 0; i < NSec; i++)
        {
            int h = SecHdr(i);
            uint vs = U32(h + 8), va = U32(h + 12), rs = U32(h + 16), rp = U32(h + 20);
            uint span = vs > rs ? vs : rs;
            if (rva >= va && rva < va + span) return (int)(rp + (rva - va));
        }
        throw new Exception("RVA 0x" + rva.ToString("x") + " 不在任何节内");
    }

    public int Extent()
    {
        int end = 0;
        for (int i = 0; i < NSec; i++)
        {
            int h = SecHdr(i);
            end = Math.Max(end, (int)(U32(h + 20) + U32(h + 16)));
        }
        return end;
    }
}

internal sealed class Meta
{
    public byte[] D;
    public Pe Pe;
    public int[] Rows = new int[64];
    public int StrSize, GuidSize, BlobSize;
    public int StrOff, StrLen, UsOff, UsLen, BlobOff, BlobLen;
    public int TableOff;
    public int[] TableStart = new int[64];

    public Meta(byte[] d)
    {
        D = d; Pe = new Pe(d);
        int ddBase = Pe.U16(Pe.Opt(0)) == 0x20b ? 112 : 96;   // PE32+ 的数据目录偏移是 112
        int clr = Pe.RvaToOff((int)Pe.U32(Pe.Opt(ddBase + 14 * 8)));
        int md = Pe.RvaToOff((int)Pe.U32(clr + 8));
        if (D[md] != 'B' || D[md + 1] != 'S' || D[md + 2] != 'J' || D[md + 3] != 'B') throw new Exception("不是 .NET 程序集");
        int verLen = (int)Pe.U32(md + 12);
        int p = (md + 16 + verLen + 3) & ~3;
        int nStream = Pe.U16(p + 2);
        p += 4;
        for (int i = 0; i < nStream; i++)
        {
            int so = (int)Pe.U32(p), ss = (int)Pe.U32(p + 4);
            int j = p + 8;
            while (D[j] != 0) j++;
            string name = Encoding.ASCII.GetString(D, p + 8, j - (p + 8));
            int at = md + so;
            if (name == "#Strings") { StrOff = at; StrLen = ss; }
            else if (name == "#US") { UsOff = at; UsLen = ss; }
            else if (name == "#Blob") { BlobOff = at; BlobLen = ss; }
            else if (name == "#~") { TableOff = at; }
            p = (j + 1 + 3) & ~3;
        }
        byte heap = D[TableOff + 6];
        StrSize = (heap & 1) != 0 ? 4 : 2;
        GuidSize = (heap & 2) != 0 ? 4 : 2;
        BlobSize = (heap & 4) != 0 ? 4 : 2;
        ulong valid = (ulong)Pe.U32(TableOff + 8) | ((ulong)Pe.U32(TableOff + 12) << 32);
        int q = TableOff + 24;
        for (int i = 0; i < 64; i++)
            if (((valid >> i) & 1) != 0) { Rows[i] = (int)Pe.U32(q); q += 4; }
        int off = q;
        for (int t = 0; t < 64; t++)
        {
            if (Rows[t] == 0) continue;
            TableStart[t] = off;
            if (t > 0x06) break;
            off += Rows[t] * RowSize(t);
        }
    }

    private int IdxSize(int t) { return Rows[t] >= 0x10000 ? 4 : 2; }
    private int CodedSize(int[] tab, int bits)
    {
        int mx = 0;
        foreach (int t in tab) if (Rows[t] > mx) mx = Rows[t];
        return mx >= (1 << (16 - bits)) ? 4 : 2;
    }
    private static readonly int[] ResolutionScope = { 0x00, 0x1A, 0x23, 0x01 };
    private static readonly int[] TypeDefOrRef = { 0x02, 0x01, 0x1B };

    public int RowSize(int t)
    {
        switch (t)
        {
            case 0x00: return 2 + StrSize + 3 * GuidSize;
            case 0x01: return CodedSize(ResolutionScope, 2) + 2 * StrSize;
            case 0x02: return 4 + 2 * StrSize + CodedSize(TypeDefOrRef, 2) + IdxSize(0x04) + IdxSize(0x06);
            case 0x03: return IdxSize(0x04);
            case 0x04: return 2 + StrSize + BlobSize;
            case 0x05: return IdxSize(0x06);
            case 0x06: return 4 + 2 + 2 + StrSize + BlobSize + IdxSize(0x08);
            default: throw new Exception("表 0x" + t.ToString("x") + " 未实现");
        }
    }

    public int RowOff(int t, int row1) { return TableStart[t] + (row1 - 1) * RowSize(t); }
    public string Str(int idx)
    {
        if (idx == 0) return "";
        int e = StrOff + idx;
        while (D[e] != 0) e++;
        return Encoding.UTF8.GetString(D, StrOff + idx, e - (StrOff + idx));
    }
    public int ReadIdx(int o, int size) { return size == 4 ? (int)Pe.U32(o) : Pe.U16(o); }
    public string TypeName(int row1)
    {
        int o = RowOff(0x02, row1);
        string n = Str(ReadIdx(o + 4, StrSize));
        string ns = Str(ReadIdx(o + 4 + StrSize, StrSize));
        return ns.Length == 0 ? n : ns + "." + n;
    }
    public int TypeMethodStart(int row1)
    {
        return ReadIdx(RowOff(0x02, row1) + 4 + 2 * StrSize + CodedSize(TypeDefOrRef, 2) + IdxSize(0x04), IdxSize(0x06));
    }
    public string MethodName(int row1) { return Str(ReadIdx(RowOff(0x06, row1) + 8, StrSize)); }
    public int MethodRva(int row1) { return (int)Pe.U32(RowOff(0x06, row1)); }
    public int MethodParamCount(int row1)
    {
        int o = RowOff(0x06, row1) + 8 + StrSize + BlobSize;
        int s = ReadIdx(o, IdxSize(0x08));
        int n = row1 < Rows[0x06] ? ReadIdx(RowOff(0x06, row1 + 1) + 8 + StrSize + BlobSize, IdxSize(0x08)) : Rows[0x08] + 1;
        return n - s;
    }
    public int BodyOff(int row1, out int codeSize)
    {
        int ho = Pe.RvaToOff(MethodRva(row1));
        ushort h = Pe.U16(ho);
        if ((h & 3) == 2) { codeSize = h >> 2; return ho + 1; }
        codeSize = (int)Pe.U32(ho + 4);
        return ho + 12;
    }
}

internal static class Program
{
    private const string BakSuffix = ".pclfix.bak";
    private static bool Silent;
    private static readonly bool Verbose = Environment.GetEnvironmentVariable("PCL2CEFIX_VERBOSE") == "1";
    private static void Dbg(string s) { if (Verbose) Console.Error.WriteLine(s); }

    private static int Main(string[] args)
    {
        bool restore = false, checkOnly = false;
        string target = null;
        foreach (string a in args)
        {
            if (a == "--restore" || a == "-r") restore = true;
            else if (a == "--check" || a == "-c") checkOnly = true;
            else if (a == "--silent" || a == "-s") Silent = true;
            else if (!a.StartsWith("-")) target = a;
        }
        if (Silent) Console.SetOut(TextWriter.Null);
        else
        {
            Console.WriteLine("==========================================================");
            Console.WriteLine("  PCL2CEFIX  社区版(CE) 下载/安装功能解锁");
            Console.WriteLine("  解锁：Minecraft 下载 / 补全 / 整合包安装（区域限制）");
            Console.WriteLine("==========================================================");
            Console.WriteLine();
        }

        if (target == null || Directory.Exists(target))
        {
            string dir = target ?? AppDomain.CurrentDomain.BaseDirectory;
            target = FindCe(dir);
            if (target == null) { Say("[×] 这个文件夹里没找到 PCL2-CE 的主程序（PCL2_CE_*.exe）。"); return Pause(2); }
            Say("[i] 自动识别到：" + Path.GetFileName(target));
        }
        if (!File.Exists(target)) { Say("[×] 文件不存在：" + target); return Pause(2); }
        target = Path.GetFullPath(target);
        Say("[i] 目标文件：" + target);

        byte[] data;
        try { data = File.ReadAllBytes(target); }
        catch (Exception ex) { Say("[×] 读取失败：" + ex.Message + "（CE 可能还开着）"); return Pause(2); }
        Say("[i] 文件大小：" + data.Length + " 字节   SHA256 " + Sha(data));

        if (restore)
        {
            string restoreBak = PickBackup(target);
            if (restoreBak == null) { Say("[×] 没找到备份（*" + BakSuffix + "）。"); return Pause(2); }
            try
            {
                EnsureClosed();
                File.Copy(restoreBak, target, true);
                Say("[√] 已还原：" + Path.GetFileName(restoreBak));
                return Pause(0);
            }
            catch (Exception ex) { Say("[×] 还原失败：" + ex.Message); return Pause(2); }
        }

        Site site;
        try { site = Locate(data); }
        catch (Exception ex)
        {
            Say("[×] 认不出来：" + ex.Message);
            Say("    工具没有改动任何文件。");
            return Pause(2);
        }

        if (site.Patched)
        {
            Say("[√] 这份 CE 已经解锁过了，不需要再改。");
            return Pause(0);
        }
        Say("[i] 找到限制判定：" + site.TypeName + "::" + site.MethodName + "（内嵌程序集偏移 0x" + site.AsmOffset.ToString("x") + "）");
        if (checkOnly) { Say("[√] 可以解锁（未改动任何文件）。"); return Pause(0); }

        string origSha = Sha(data);
        string bak = BakPathFor(target, origSha);
        FileStream fs = null;
        try
        {
            if (!File.Exists(bak)) { File.Copy(target, bak, false); Say("[√] 已备份原版 → " + Path.GetFileName(bak)); }
            fs = new FileStream(target, FileMode.Open, FileAccess.ReadWrite, FileShare.None);
            byte[] work = (byte[])data.Clone();
            int abs = site.AsmOffset + site.BodyOffset;
            work[abs + 0] = 0x17;   // ldc.i4.1
            work[abs + 1] = 0x2A;   // ret
            for (int i = 2; i < site.HeadLen; i++) work[abs + i] = 0x00; // nop 填充
            fs.Position = 0; fs.Write(work, 0, work.Length); fs.Flush();
            fs.Close(); fs = null;
            File.WriteAllText(target + ".pclfix.state", "orig=" + origSha + "\r\ntime=" + DateTime.Now.ToString("s"));

            byte[] verify = File.ReadAllBytes(target);
            Site after = Locate(verify);
            if (!after.Patched)
            {
                Say("[×] 写入后复查未通过。请用备份还原：" + bak);
                return Pause(2);
            }
            Say("");
            Say("[√] 解锁成功，复查通过。");
            Say("    新文件 SHA256：" + Sha(verify));
            Say("    重新打开 CE：下载 / 开始下载 / 整合包安装 都不再被区域限制拦住。");
            Say("    想改回去：本工具加 --restore。");
            return Pause(0);
        }
        catch (Exception ex)
        {
            if (fs != null) { try { fs.Close(); } catch { } }
            Say("[×] 写入失败：" + ex.Message);
            Say("    如果 CE 正在运行，请先完全退出。");
            return Pause(2);
        }
    }

    private sealed class Site
    {
        public int AsmOffset;      // 内嵌程序集在 exe 里的起始偏移
        public int BodyOffset;     // 方法体相对程序集的偏移
        public int HeadLen = 16;   // 开头 16 字节（call/stloc/ldloc/callvirt/brtrue/ldc/ret）
        public bool Patched;       // 已经是解锁状态
        public string TypeName, MethodName;
    }

    /// <summary>在单文件 exe 里找内嵌托管程序集，并定位受限判定方法。</summary>
    private static Site Locate(byte[] data)
    {
        int i = 0;
        string lastErr = null;
        while (true)
        {
            i = IndexOf(data, new byte[] { (byte)'M', (byte)'Z' }, i);
            if (i < 0) break;
            try
            {
                if (i + 0x40 < data.Length)
                {
                    int pe = (int)BitConverter.ToUInt32(data, i + 0x3c);
                    if (pe > 0x40 && pe < 0x400 && i + pe + 4 <= data.Length
                        && data[i + pe] == 'P' && data[i + pe + 1] == 'E')
                    {
                        int extent = ComputeExtent(data, i);
                        if (extent > 0 && i + extent <= data.Length)
                        {
                            var asm = new Meta(Slice(data, i, extent));
                            var s = AnalyzeAssembly(asm, i);
                            if (s != null) return s;
                            Dbg("MZ@0x" + i.ToString("x") + " 是 .NET 程序集(types=" + asm.Rows[0x02] + ")，但没有限制判定");
                        }
                    }
                }
            }
            catch (Exception ex) { lastErr = ex.Message; Dbg("MZ@0x" + i.ToString("x") + " 解析失败: " + ex.Message); }
            i += 1;
        }
        throw new Exception(lastErr == null ? "没有找到含受限判定的程序集" : lastErr);
    }

    private static int ComputeExtent(byte[] d, int mz)
    {
        int pe = (int)BitConverter.ToUInt32(d, mz + 0x3c);
        int nsec = BitConverter.ToUInt16(d, mz + pe + 6);
        int optsz = BitConverter.ToUInt16(d, mz + pe + 20);
        int s = mz + pe + 24 + optsz;
        int end = 0;
        for (int k = 0; k < nsec; k++)
        {
            uint rs = BitConverter.ToUInt32(d, s + k * 40 + 16);
            uint rp = BitConverter.ToUInt32(d, s + k * 40 + 20);
            end = Math.Max(end, (int)(rp + rs));
        }
        return end;
    }

    private static Site AnalyzeAssembly(Meta asm, int asmOffset)
    {
        int t = 0;
        for (int r = 1; r <= asm.Rows[0x02]; r++)
        {
            string nm = asm.TypeName(r);
            if (nm.Contains("Restricted") || nm.Contains("Region")) Dbg("  hit type[" + r + "] = " + nm);
            if (nm == "PCL.RestrictedFeaturePolicy") { t = r; break; }
        }
        if (t == 0) return null;

        int start = asm.TypeMethodStart(t);
        int end = t < asm.Rows[0x02] ? asm.TypeMethodStart(t + 1) : asm.Rows[0x06] + 1;
        for (int m = start; m < end; m++)
        {
            if (asm.MethodName(m) != "Check") continue;
            // 参数个数只作参考：不同版本可能加参数，真正的判定依据是下面的字节形态
            if (asm.MethodParamCount(m) < 1) continue;
            int code;
            int body = asm.BodyOff(m, out code);
            if (code < 16) continue;
            byte b0 = asm.D[body], b1 = asm.D[body + 1];
            byte b5 = asm.D[body + 5], b6 = asm.D[body + 6];
            var site = new Site { AsmOffset = asmOffset, BodyOffset = body, TypeName = "PCL.RestrictedFeaturePolicy", MethodName = "Check" };
            // 已解锁形态：ldc.i4.1 ; ret ; nop...
            if (b0 == 0x17 && b1 == 0x2A) { site.Patched = true; return site; }
            // 原始形态：call Assess ; stloc.0 ; ldloc.0 ; callvirt ...
            bool looksOriginal = b0 == 0x28 && b5 == 0x0A && b6 == 0x06;
            if (!looksOriginal) continue;
            site.Patched = false;
            return site;
        }
        return null;
    }

    private static string FindCe(string dir)
    {
        string self = "";
        try { self = Path.GetFullPath(System.Reflection.Assembly.GetExecutingAssembly().Location); } catch { }
        var hits = new List<string>();
        try
        {
            foreach (string f in Directory.GetFiles(dir, "*.exe"))
            {
                string full = Path.GetFullPath(f);
                if (string.Equals(full, self, StringComparison.OrdinalIgnoreCase)) continue;
                long len;
                try { len = new FileInfo(full).Length; } catch { continue; }
                if (len < 5000000) continue;          // CE 主程序 20 MB 以上，太小的直接跳过
                try
                {
                    byte[] d = File.ReadAllBytes(full);
                    Locate(d);                         // 能定位到限制判定的，就是 CE 主程序
                    hits.Add(full);
                }
                catch { }
            }
        }
        catch { return null; }
        if (hits.Count == 0) return null;
        hits.Sort((a, b) => new FileInfo(b).Length.CompareTo(new FileInfo(a).Length));
        return hits[0];
    }

    private static string BakPathFor(string target, string sha) { return target + BakSuffix + "." + sha.Substring(0, 8); }

    private static string PickBackup(string target)
    {
        string state = target + ".pclfix.state";
        if (File.Exists(state))
        {
            try
            {
                foreach (string line in File.ReadAllLines(state))
                    if (line.StartsWith("orig="))
                    {
                        string cand2 = BakPathFor(target, line.Substring(5).Trim());
                        if (File.Exists(cand2)) return cand2;
                    }
            }
            catch { }
        }
        string dir = Path.GetDirectoryName(target);
        string best = null; DateTime bestTime = DateTime.MinValue;
        try
        {
            foreach (string f in Directory.GetFiles(dir, Path.GetFileName(target) + BakSuffix + ".*"))
            {
                DateTime tt = File.GetLastWriteTimeUtc(f);
                if (tt > bestTime) { bestTime = tt; best = f; }
            }
        }
        catch { }
        return best;
    }

    private static void EnsureClosed()
    {
        foreach (var p in System.Diagnostics.Process.GetProcessesByName("PCL2_CE_x64"))
            if (p.MainWindowHandle != IntPtr.Zero) throw new Exception("CE 正在运行，请先完全退出");
    }

    private static byte[] Slice(byte[] d, int off, int len) { byte[] r = new byte[len]; Buffer.BlockCopy(d, off, r, 0, len); return r; }
    private static int IndexOf(byte[] hay, byte[] needle, int start)
    {
        for (int i = start; i <= hay.Length - needle.Length; i++)
        {
            bool ok = true;
            for (int j = 0; j < needle.Length; j++) if (hay[i + j] != needle[j]) { ok = false; break; }
            if (ok) return i;
        }
        return -1;
    }
    private static string Sha(byte[] d)
    {
        using (var s = SHA256.Create())
        {
            var h = s.ComputeHash(d);
            var sb = new StringBuilder(h.Length * 2);
            foreach (byte b in h) sb.Append(b.ToString("X2"));
            return sb.ToString();
        }
    }
    private static void Say(string s) { if (!Silent) Console.WriteLine(s); }
    private static int Pause(int code)
    {
        if (Silent) return code;
        Console.WriteLine();
        Console.WriteLine("按任意键退出…");
        try { Console.ReadKey(true); } catch { }
        return code;
    }
}
