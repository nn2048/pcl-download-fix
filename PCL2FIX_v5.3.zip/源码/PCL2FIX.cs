// PCL2FIX —— 结构化（按名字）自适应补丁器
// 不再依赖任何固定字节/固定偏移：所有 token 与偏移都从目标 exe 自己的元数据里现算。
//
// 适配对象：同族 PCL2（2.13+ / 2.99 正式版与快照版）
//   补丁 1：PageDownloadInstall.LoaderInit 里被换成“哑 LoaderTask”的真加载器
//   补丁 2：ModModpack.ModpackInstall 里被换成 throw 的 7 路分发
using System;
using System.Collections.Generic;
using System.IO;
using System.Security.Cryptography;
using System.Text;

internal sealed class Pe
{
    public byte[] D;
    public int PeOff, NSec, OptSize, OptOff, SecOff;
    public int Opt(int rel) { return OptOff + rel; }
    public uint U32(int o) { return (uint)(D[o] | D[o + 1] << 8 | D[o + 2] << 16 | D[o + 3] << 24); }
    public int I32(int o) { return (int)U32(o); }
    public ushort U16(int o) { return (ushort)(D[o] | D[o + 1] << 8); }
    public void W32(int o, uint v) { D[o] = (byte)v; D[o + 1] = (byte)(v >> 8); D[o + 2] = (byte)(v >> 16); D[o + 3] = (byte)(v >> 24); }

    public Pe(byte[] d)
    {
        D = d;
        PeOff = I32(0x3c);
        NSec = U16(PeOff + 6);
        OptSize = U16(PeOff + 20);
        OptOff = PeOff + 24;
        SecOff = OptOff + OptSize;
    }

    public int SecHdr(int i) { return SecOff + i * 40; }
    public uint SizeOfImage { get { return U32(Opt(56)); } }
    public uint FileAlign { get { return U32(Opt(36)); } }

    public int RvaToOff(int rva)
    {
        for (int i = 0; i < NSec; i++)
        {
            int h = SecHdr(i);
            uint vs = U32(h + 8), va = U32(h + 12), rs = U32(h + 16), rp = U32(h + 20);
            uint span = vs > rs ? vs : rs;
            if (rva >= va && rva < va + span) return (int)(rp + (rva - va));
        }
        throw new Exception("RVA 0x" + rva.ToString("x") + " 不在任何节内");
    }
}

internal sealed class Meta
{
    public byte[] D;
    public Pe Pe;
    public int[] Rows = new int[64];
    public int StrSize, GuidSize, BlobSize;
    public int StrOff, StrLen, UsOff, UsLen, BlobOff, BlobLen, GuidOff, GuidLen;
    public int TableOff;
    public int[] TableStart = new int[64];

    public Meta(byte[] d)
    {
        D = d; Pe = new Pe(d);
        int ddBase = Pe.U16(Pe.Opt(0)) == 0x20b ? 112 : 96;   // PE32+ 的数据目录偏移是 112
        int clr = Pe.RvaToOff((int)Pe.U32(Pe.Opt(ddBase + 14 * 8)));
        int md = Pe.RvaToOff((int)Pe.U32(clr + 8));
        if (D[md] != 'B' || D[md + 1] != 'S' || D[md + 2] != 'J' || D[md + 3] != 'B')
            throw new Exception("不是 .NET 程序集");
        int verLen = (int)Pe.U32(md + 12);
        int p = (md + 16 + verLen + 3) & ~3;
        int nStream = Pe.U16(p + 2);
        p += 4;
        for (int i = 0; i < nStream; i++)
        {
            int so = (int)Pe.U32(p), ss = (int)Pe.U32(p + 4);
            int j = p + 8;
            while (D[j] != 0) j++;
            string name = Encoding.ASCII.GetString(D, p + 8, j - (p + 8));
            int at = md + so;
            if (name == "#Strings") { StrOff = at; StrLen = ss; }
            else if (name == "#US") { UsOff = at; UsLen = ss; }
            else if (name == "#Blob") { BlobOff = at; BlobLen = ss; }
            else if (name == "#GUID") { GuidOff = at; GuidLen = ss; }
            else if (name == "#~") { TableOff = at; }
            p = (j + 1 + 3) & ~3;
        }
        byte heap = D[TableOff + 6];
        StrSize = (heap & 1) != 0 ? 4 : 2;
        GuidSize = (heap & 2) != 0 ? 4 : 2;
        BlobSize = (heap & 4) != 0 ? 4 : 2;

        ulong valid = (ulong)Pe.U32(TableOff + 8) | ((ulong)Pe.U32(TableOff + 12) << 32);
        int q = TableOff + 24;
        for (int i = 0; i < 64; i++)
            if (((valid >> i) & 1) != 0) { Rows[i] = (int)Pe.U32(q); q += 4; }

        int off = q;
        for (int t = 0; t < 64; t++)
        {
            if (Rows[t] == 0) continue;
            TableStart[t] = off;
            if (t > 0x06) break;              // 后面的表不需要定位，别去算它的大小
            off += Rows[t] * RowSize(t);
        }
    }

    private int IdxSize(int t) { return Rows[t] >= 0x10000 ? 4 : 2; }
    private int CodedSize(int[] tab, int bits)
    {
        int mx = 0;
        foreach (int t in tab) if (Rows[t] > mx) mx = Rows[t];
        return mx >= (1 << (16 - bits)) ? 4 : 2;
    }

    private static readonly int[] ResolutionScope = { 0x00, 0x1A, 0x23, 0x01 };
    private static readonly int[] TypeDefOrRef = { 0x02, 0x01, 0x1B };

    public int RowSize(int t)
    {
        switch (t)
        {
            case 0x00: return 2 + StrSize + 3 * GuidSize;
            case 0x01: return CodedSize(ResolutionScope, 2) + 2 * StrSize;
            case 0x02: return 4 + 2 * StrSize + CodedSize(TypeDefOrRef, 2) + IdxSize(0x04) + IdxSize(0x06);
            case 0x03: return IdxSize(0x04);
            case 0x04: return 2 + StrSize + BlobSize;
            case 0x05: return IdxSize(0x06);
            case 0x06: return 4 + 2 + 2 + StrSize + BlobSize + IdxSize(0x08);
            default: throw new Exception("表 0x" + t.ToString("x") + " 未实现（本工具只需要 0x00-0x06）");
        }
    }

    public int RowOff(int t, int row1) { return TableStart[t] + (row1 - 1) * RowSize(t); }

    public string Str(int idx)
    {
        if (idx == 0) return "";
        int e = StrOff + idx;
        while (D[e] != 0) e++;
        return Encoding.UTF8.GetString(D, StrOff + idx, e - (StrOff + idx));
    }

    public int ReadIdx(int o, int size) { return size == 4 ? (int)Pe.U32(o) : Pe.U16(o); }

    public string TypeName(int row1)
    {
        int o = RowOff(0x02, row1);
        int nameIdx = ReadIdx(o + 4, StrSize);
        int nsIdx = ReadIdx(o + 4 + StrSize, StrSize);
        string n = Str(nameIdx), ns = Str(nsIdx);
        return ns.Length == 0 ? n : ns + "." + n;
    }

    public int TypeNameIdx(int row1) { return ReadIdx(RowOff(0x02, row1) + 4, StrSize); }

    public int TypeFieldStart(int row1) { return ReadIdx(RowOff(0x02, row1) + 4 + 2 * StrSize + CodedSize(TypeDefOrRef, 2), IdxSize(0x04)); }
    public int TypeMethodStart(int row1) { return ReadIdx(RowOff(0x02, row1) + 4 + 2 * StrSize + CodedSize(TypeDefOrRef, 2) + IdxSize(0x04), IdxSize(0x06)); }

    public int MethodNameIdx(int row1) { return ReadIdx(RowOff(0x06, row1) + 8, StrSize); }
    public string MethodName(int row1) { return Str(MethodNameIdx(row1)); }
    public int MethodRva(int row1) { return (int)Pe.U32(RowOff(0x06, row1)); }
    public int MethodParamStart(int row1) { return ReadIdx(RowOff(0x06, row1) + 8 + StrSize + BlobSize, IdxSize(0x08)); }
    public int MethodParamCount(int row1)
    {
        int s = MethodParamStart(row1);
        int n = row1 < Rows[0x06] ? MethodParamStart(row1 + 1) : Rows[0x08] + 1;
        return n - s;
    }

    public int FieldNameIdx(int row1) { return ReadIdx(RowOff(0x04, row1) + 2, StrSize); }
    public string FieldName(int row1) { return Str(FieldNameIdx(row1)); }

    public int MethodBodySize(int row1, out int headerOff)
    {
        headerOff = Pe.RvaToOff(MethodRva(row1));
        int h = Pe.U16(headerOff);
        if ((h & 3) == 2) return h >> 2;
        return (int)Pe.U32(headerOff + 4);
    }
    public int MethodBodyStart(int row1) { int h; int n = MethodBodySize(row1, out h); return (Pe.U16(h) & 3) == 2 ? h + 1 : h + 12; }
}

internal static class Program
{
    private const string ExeName = "Plain Craft Launcher 2.exe";
    private const string BakSuffix = ".pclfix.bak";
    private static bool Silent;
    private static readonly string[] Installers = {
        "InstallPackCurseForge", "InstallPackModrinth", "InstallPackHMCL", "InstallPackMMC",
        "InstallPackMCBBS", "InstallPackLauncherPack", "InstallPackCompress" };
    private static readonly int[] ArgCount = { 5, 5, 3, 3, 4, 3, 2 };
    private const string Notice = "为遵守相关法律法规";

    private static int Main(string[] args)
    {
        bool restore = false, checkOnly = false;
        string target = null;
        foreach (string a in args)
        {
            if (a == "--restore" || a == "-r") restore = true;
            else if (a == "--check" || a == "-c") checkOnly = true;
            else if (a == "--silent" || a == "-s") Silent = true;
            else if (!a.StartsWith("-")) target = a;
        }
        if (Silent) Console.SetOut(TextWriter.Null);
        else Banner();

        if (target == null || Directory.Exists(target))
        {
            string dir = target ?? AppDomain.CurrentDomain.BaseDirectory;
            target = FindLauncher(dir);
            if (target == null)
            {
                Say("[×] 这个文件夹里没找到 PCL 启动器。");
                Say("    把本工具和 PCL 的 exe 放在同一个文件夹，或把 exe 拖到本工具上。");
                return Pause(2);
            }
            Say("[i] 自动识别到启动器：" + Path.GetFileName(target));
        }
        if (!File.Exists(target))
        {
            Say("[×] 文件不存在：" + target);
            return Pause(2);
        }
        target = Path.GetFullPath(target);
        Say("[i] 目标文件：" + target);

        if (restore)
        {
            string bak = PickBackup(target);
            if (bak == null) { Say("[×] 没找到任何备份（*" + BakSuffix + "）。"); return Pause(2); }
            try
            {
                EnsureClosed(target);
                File.Copy(bak, target, true);
                File.Delete(StatePath(target));
                Say("[√] 已从备份还原：" + Path.GetFileName(bak));
                Say("    还原后的 SHA256：" + Sha(File.ReadAllBytes(target)));
                return Pause(0);
            }
            catch (Exception ex) { Say("[×] 还原失败：" + ex.Message); return Pause(2); }
        }

        byte[] data;
        try { data = File.ReadAllBytes(target); }
        catch (Exception ex) { Say("[×] 读取失败：" + ex.Message + "（PCL 可能还开着）"); return Pause(2); }

        Say("[i] 文件大小：" + data.Length + " 字节   SHA256 " + Sha(data));

        Plan plan;
        try { plan = MakePlan(data); }
        catch (Exception ex)
        {
            Say("[×] 这份 exe 认不出来：" + ex.Message);
            Say("    工具没有改动任何文件。请把这只 exe 发给作者。");
            return Pause(2);
        }

        if (!plan.Patch1 && !plan.Patch2 && !plan.Patch3 && !plan.Patch4)
        {
            Say("[√] 这份 PCL 不需要补丁（拦截都不存在，或是已经修好的状态）。");
            return Pause(0);
        }
        Say("[i] 检测结果：" + (plan.Patch1 ? "需要补丁 1（下载页）  " : "补丁 1 已就绪  ")
            + (plan.Patch2 ? "需要补丁 2（整合包安装）  " : "补丁 2 已就绪  ")
            + (plan.Patch3 ? "需要补丁 3（提示文案）  " : "补丁 3 已就绪  ")
            + (plan.Patch4 ? "需要补丁 4（原版游戏入口）" : "补丁 4 已就绪"));

        if (checkOnly)
        {
            Say("[√] 可以修补（未改动任何文件）。");
            return Pause(0);
        }

        string origSha = Sha(data);
        string bakPath = BakPathFor(target, origSha);
        FileStream fs = null;
        try
        {
            if (!File.Exists(bakPath))
            {
                File.Copy(target, bakPath, false);
                Say("[√] 已备份这份原版 → " + Path.GetFileName(bakPath));
            }
            else Say("[i] 这份原版的备份已存在：" + Path.GetFileName(bakPath));

            fs = new FileStream(target, FileMode.Open, FileAccess.ReadWrite, FileShare.None);
            byte[] work = (byte[])data.Clone();
            if (plan.Patch1) { PatchLoaderInit(work, plan); Say("[i] 补丁 1：下载页拦截 → 已解除"); }
            if (plan.Patch2) { work = PatchModpack(work, plan); Say("[i] 补丁 2：整合包安装拦截 → 已解除"); }
            if (plan.Patch3) { TryRewriteNotice(work, plan); Say("[i] 补丁 3：残留提示文案 → 已改为操作指引（“导入整合包”按钮不再显示法规提示）"); }
            if (plan.Patch4) { PatchV4(work, plan); Say("[i] 补丁 4：下载页「原版游戏」入口 → 已恢复显示（新版把它折叠了）"); }

            fs.Position = 0; fs.Write(work, 0, work.Length); fs.SetLength(work.Length); fs.Flush();
            fs.Close(); fs = null;
            File.WriteAllText(StatePath(target), "orig=" + origSha + "\r\ntime=" + DateTime.Now.ToString("s"));

            byte[] verify = File.ReadAllBytes(target);
            Plan after = MakePlan(verify);
            if (after.Patch1 || after.Patch2 || after.Patch3 || after.Patch4 || after.Error != null)
            {
                Say("[×] 写入后复查未通过：仍然检测到未修复的拦截点。请用备份还原：" + bakPath);
                return Pause(2);
            }
            Say("");
            Say("[√] 补丁写入成功，复查通过。");
            Say("    新文件 SHA256：" + Sha(verify));
            Say("    现在应该恢复：下载 → 原版游戏（版本列表/安装）；拖入整合包 / 整合包市场安装。");
            Say("    想改回去：本工具加 --restore 参数。");
            return Pause(0);
        }
        catch (Exception ex)
        {
            if (fs != null) { try { fs.Close(); } catch { } }
            Say("[×] 写入失败：" + ex.Message);
            Say("    如果 PCL 正在运行，请先完全退出（含托盘）。");
            return Pause(2);
        }
    }

    private sealed class Plan
    {
        public bool Patch1, Patch2, Patch3, Patch4;
        public int P4Row, P4Body;
        public string Error;
        public int LoaderRow, ModpackRow, LoaderBodySize, ModpackBodySize;
        public int LoaderTok, NoticeTok;
        public Dictionary<string, int> InstallerToks = new Dictionary<string, int>();
    }

    private static Plan MakePlan(byte[] data)
    {
        var p = new Plan();
        var m = new Meta(data);
        AnalyzeV4(m, p);

        int liType = FindType(m, "PCL.PageDownloadInstall");
        if (liType == 0) throw new Exception("没有 PCL.PageDownloadInstall 类型");
        int li = FindMethod(m, liType, "LoaderInit");
        if (li == 0) throw new Exception("没有 PageDownloadInstall.LoaderInit");
        p.LoaderRow = li;
        int dummyHead;
        p.LoaderBodySize = m.MethodBodySize(li, out dummyHead);

        int loaderField = FindField(m, "DlClientListLoader");
        if (loaderField == 0) throw new Exception("没有 DlClientListLoader 字段");
        p.LoaderTok = 0x04000000 | loaderField;
        byte[] liBody = Slice(data, m.MethodBodyStart(li), p.LoaderBodySize);
        p.Patch1 = IndexOf(liBody, Le((uint)p.LoaderTok)) < 0;

        int mpType = FindType(m, "PCL.ModModpack");
        if (mpType == 0) throw new Exception("没有 PCL.ModModpack 类型");
        int mp = 0;
        int start = m.TypeMethodStart(mpType);
        int end = mpType < m.Rows[0x02] ? m.TypeMethodStart(mpType + 1) : m.Rows[0x06] + 1;
        for (int i = start; i < end; i++)
            if (m.MethodName(i) == "ModpackInstall" && m.MethodBodySize(i, out dummyHead) > 100) { mp = i; break; }
        if (mp == 0) throw new Exception("没有 ModModpack.ModpackInstall(File,...)");
        p.ModpackRow = mp;
        int mpHdr;
        p.ModpackBodySize = m.MethodBodySize(mp, out mpHdr);

        int us = 0;
        byte[] needle = Encoding.Unicode.GetBytes(Notice);
        for (int i = m.UsOff; i < m.UsOff + m.UsLen - needle.Length; i++)
            if (Eq(data, i, needle)) { us = i; break; }
        if (us == 0)
        {
            // 没有那条公告字符串 = 这一版根本没有“删下载功能”的改动（比如 2.12.x），不需要补丁
            p.Patch2 = false;
            return p;
        }
        p.NoticeTok = 0x70000000 | (us - m.UsOff - 1);

        byte[] mpBody = Slice(data, m.MethodBodyStart(mp), p.ModpackBodySize);
        byte[] throwPat = Concat(new byte[] { 0x72 }, Le((uint)p.NoticeTok), new byte[] { 0x73 });
        p.Patch2 = IndexOf(mpBody, throwPat) >= 0;
        p.Patch3 = NoticeStillOriginal(data, p.NoticeTok);
        if (!p.Patch2) return p;

        foreach (string n in Installers)
        {
            int r = 0;
            for (int i = start; i < end; i++) if (m.MethodName(i) == n) { r = i; break; }
            if (r == 0) throw new Exception("缺少安装器 " + n);
            p.InstallerToks[n] = 0x06000000 | r;
        }
        return p;
    }

    private static void PatchLoaderInit(byte[] data, Plan p)
    {
        var m = new Meta(data);
        int bodyOff = m.MethodBodyStart(p.LoaderRow);
        byte[] b = Slice(data, bodyOff, p.LoaderBodySize);
        int iNull = IndexOf(b, new byte[] { 0x14, 0x72 });
        int jTask = IndexOf(b, new byte[] { 0x14, 0x18, 0x73 });
        if (iNull < 0 || jTask <= iNull) throw new Exception("LoaderInit 结构与预期不符");
        int s = iNull + 1, e = jTask + 7;
        byte[] rep = Le((uint)p.LoaderTok);
        byte[] seg = new byte[e - s];
        for (int i = 0; i < seg.Length; i++) seg[i] = 0;
        seg[0] = 0x7e;
        Buffer.BlockCopy(rep, 0, seg, 1, 4);
        Buffer.BlockCopy(seg, 0, data, bodyOff + s, seg.Length);
    }

    private static byte[] PatchModpack(byte[] data, Plan p)
    {
        var m = new Meta(data);
        int hdr = 0;
        int code = m.MethodBodySize(p.ModpackRow, out hdr);
        int codeOff = m.MethodBodyStart(p.ModpackRow);
        byte[] body = Slice(data, codeOff, code);
        byte[] throwPat = Concat(new byte[] { 0x72 }, Le((uint)p.NoticeTok), new byte[] { 0x73 });
        int throwAt = IndexOf(body, throwPat);
        if (throwAt < 0) throw new Exception("找不到 notice throw");

        int ehPos = (hdr + 12 + code + 3) & ~3;
        int ehSize = data[ehPos + 1] | data[ehPos + 2] << 8 | data[ehPos + 3] << 16;
        int nc = (ehSize - 4) / 24;
        var keep = new List<byte[]>();
        int outerIdx = -1, handlerOff = -1, handlerLen = 0;
        for (int k = 0; k < nc; k++)
        {
            int o = ehPos + 4 + k * 24;
            uint fl = m.Pe.U32(o), ho = m.Pe.U32(o + 12), hl = m.Pe.U32(o + 16);
            byte[] c = Slice(data, o, 24);
            if (fl == 2 && ho == throwAt + 11) { outerIdx = k; handlerOff = (int)ho; handlerLen = (int)hl; }
            keep.Add(c);
        }
        if (outerIdx < 0) throw new Exception("找不到外层 finally 从句");
        keep.RemoveAt(outerIdx);

        byte[] nb = new byte[handlerOff + handlerLen - throwAt];
        Array.Copy(body, 0, body, 0, body.Length);
        for (int i = throwAt; i < handlerOff + handlerLen; i++) body[i] = 0;

        byte[] disp = BuildDispatch(p.InstallerToks);
        byte[] body2 = Concat(body, disp);

        int maxstack = m.Pe.U16(hdr + 2);
        uint flags = m.Pe.U32(hdr) & 0xFFFF;
        uint localsig = m.Pe.U32(hdr + 8);
        byte[] head = Concat(Le(flags, 2), Le((uint)maxstack, 2), Le((uint)body2.Length, 4), Le(localsig, 4));
        byte[] eh = Concat(new byte[] { 0x41 }, Le((uint)(4 + 24 * keep.Count), 3), Join(keep));
        byte[] nb2 = Concat(head, body2);
        nb2 = Pad(nb2);
        nb2 = Concat(nb2, eh);
        nb2 = Pad(nb2);

        var pe = m.Pe;
        int last = pe.SecHdr(pe.NSec - 1);
        uint vs = pe.U32(last + 8), va = pe.U32(last + 12), rs = pe.U32(last + 16), rp = pe.U32(last + 20);
        uint chars = pe.U32(last + 36);
        if ((long)rp + rs != data.Length) throw new Exception("最后一段原始数据没有贴着文件尾，无法追加");
        int newRva = (int)(va + (data.Length - rp));

        int blobLen = ((nb2.Length + 0x3ff) / 0x400) * 0x400;
        if (blobLen == 0) blobLen = 0x400;
        byte[] blob = new byte[blobLen];
        Buffer.BlockCopy(nb2, 0, blob, 0, nb2.Length);

        byte[] grown = Concat(data, blob);
        var pe2 = new Pe(grown);
        int last2 = pe2.SecHdr(pe2.NSec - 1);
        uint newRs = rs + (uint)blobLen;
        pe2.W32(last2 + 8, Math.Max(vs, newRs));
        pe2.W32(last2 + 16, newRs);
        pe2.W32(last2 + 36, (chars & ~0x02000000u) | 0x40000000u);
        uint need = (va + Math.Max(vs, newRs) + 0xFFF) & ~0xFFFu;
        if (need > pe2.SizeOfImage) pe2.W32(pe2.Opt(56), need);
        int align = (int)pe2.FileAlign;
        while (grown.Length % align != 0) grown = Concat(grown, new byte[] { 0 });

        var m2 = new Meta(grown);
        int rowOff = m2.RowOff(0x06, p.ModpackRow);
        m2.Pe.W32(rowOff, (uint)newRva);

        return grown;
    }

    private static byte[] BuildDispatch(Dictionary<string, int> tok)
    {
        var a5 = new byte[] { 0x02, 0x07, 0x08, 0x03, 0x04 };
        var a4 = new byte[] { 0x02, 0x07, 0x08, 0x03 };
        var a3 = new byte[] { 0x02, 0x07, 0x08 };
        var a2 = new byte[] { 0x02, 0x07 };
        Func<byte[], int, byte[]> blk = (args, tokv) => Concat(args, new byte[] { 0x28 }, Le((uint)tokv), new byte[] { 0x2a });

        byte[] cf = blk(a5, tok["InstallPackCurseForge"]);
        byte[] hmcl = blk(a3, tok["InstallPackHMCL"]);
        byte[] mmc = blk(a3, tok["InstallPackMMC"]);
        byte[] mcbbs = blk(a4, tok["InstallPackMCBBS"]);
        byte[] modr = blk(a5, tok["InstallPackModrinth"]);
        byte[] lp = blk(a3, tok["InstallPackLauncherPack"]);
        byte[] comp = blk(a2, tok["InstallPackCompress"]);

        int head = 2 + 1 + 4 + 5 * 4;
        int tail = 2 + 2 + 2 + 2;
        int oComp = head + tail;
        int oCf = oComp + comp.Length;
        int oHmcl = oCf + cf.Length;
        int oMmc = oHmcl + hmcl.Length;
        int oMcbbs = oMmc + mmc.Length;
        int oModr = oMcbbs + mcbbs.Length;
        int oLp = oModr + modr.Length;

        int[] tg = { oCf - head, oHmcl - head, oMmc - head, oMcbbs - head, oModr - head };
        byte[] sw = Concat(new byte[] { 0x45 }, Le(5u), Le((uint)tg[0]), Le((uint)tg[1]), Le((uint)tg[2]), Le((uint)tg[3]), Le((uint)tg[4]));
        byte beq = (byte)(sbyte)(oLp - (head + 6));
        byte br = (byte)(sbyte)(oComp - (head + 8));
        byte[] tailb = Concat(new byte[] { 0x11, 0x04, 0x1f, 0x09, 0x2e, beq, 0x2b, br });

        return Concat(new byte[] { 0x11, 0x04 }, sw, tailb, comp, cf, hmcl, mmc, mcbbs, modr, lp);
    }

    // ---------- helpers ----------
    private static int FindType(Meta m, string full)
    {
        for (int t = 1; t <= m.Rows[0x02]; t++) if (m.TypeName(t) == full) return t;
        return 0;
    }
    private static int FindMethod(Meta m, int type, string name)
    {
        int s = m.TypeMethodStart(type);
        int e = type < m.Rows[0x02] ? m.TypeMethodStart(type + 1) : m.Rows[0x06] + 1;
        for (int i = s; i < e; i++) if (m.MethodName(i) == name) return i;
        return 0;
    }
    private static int FindField(Meta m, string name)
    {
        for (int i = 1; i <= m.Rows[0x04]; i++) if (m.FieldName(i) == name) return i;
        return 0;
    }
    private static byte[] Slice(byte[] d, int off, int len) { byte[] r = new byte[len]; Buffer.BlockCopy(d, off, r, 0, len); return r; }
    private static byte[] Le(uint v) { return new byte[] { (byte)v, (byte)(v >> 8), (byte)(v >> 16), (byte)(v >> 24) }; }
    private static byte[] Le(uint v, int n) { byte[] r = new byte[n]; for (int i = 0; i < n; i++) r[i] = (byte)(v >> (8 * i)); return r; }
    private static byte[] Pad(byte[] b) { int n = (b.Length + 3) & ~3; if (n == b.Length) return b; byte[] r = new byte[n]; Buffer.BlockCopy(b, 0, r, 0, b.Length); return r; }
    private static byte[] Join(List<byte[]> parts) { int n = 0; foreach (var p in parts) n += p.Length; byte[] r = new byte[n]; int o = 0; foreach (var p in parts) { Buffer.BlockCopy(p, 0, r, o, p.Length); o += p.Length; } return r; }
    private static byte[] Concat(params byte[][] parts) { return Join(new List<byte[]>(parts)); }
    private static int IndexOf(byte[] hay, byte[] needle)
    {
        for (int i = 0; i <= hay.Length - needle.Length; i++)
        {
            bool ok = true;
            for (int j = 0; j < needle.Length; j++) if (hay[i + j] != needle[j]) { ok = false; break; }
            if (ok) return i;
        }
        return -1;
    }
    private static bool Eq(byte[] a, int off, byte[] b)
    {
        for (int i = 0; i < b.Length; i++) if (a[off + i] != b[i]) return false;
        return true;
    }

    private static string StatePath(string target) { return target + ".pclfix.state"; }

    private static string BakPathFor(string target, string sha) { return target + BakSuffix + "." + sha.Substring(0, 8); }

    /// <summary>找这个文件夹里的 PCL 启动器：不看文件名，看它是不是 PCL 的程序集。</summary>
    private static string FindLauncher(string dir)
    {
        string self = "";
        try { self = Path.GetFullPath(System.Reflection.Assembly.GetExecutingAssembly().Location); } catch { }
        var cand = new List<string>();
        try
        {
            foreach (string f in Directory.GetFiles(dir, "*.exe"))
            {
                string full = Path.GetFullPath(f);
                if (string.Equals(full, self, StringComparison.OrdinalIgnoreCase)) continue;
                long len;
                try { len = new FileInfo(full).Length; } catch { continue; }
                if (len < 1000000 || len > 80L * 1024 * 1024) continue;
                try
                {
                    var m = new Meta(File.ReadAllBytes(full));
                    if (FindType(m, "PCL.Application") != 0 || FindType(m, "PCL.ModMain") != 0)
                        cand.Add(full);
                }
                catch { }
            }
        }
        catch { return null; }
        if (cand.Count == 0) return null;
        cand.Sort((a, b) =>
        {
            bool pa = Path.GetFileName(a).ToUpperInvariant().Contains("PCL");
            bool pb = Path.GetFileName(b).ToUpperInvariant().Contains("PCL");
            if (pa != pb) return pa ? -1 : 1;
            long la = 0, lb = 0;
            try { la = new FileInfo(a).Length; } catch { }
            try { lb = new FileInfo(b).Length; } catch { }
            return lb.CompareTo(la);
        });
        return cand[0];
    }

    /// <summary>还原时选哪份备份：优先状态文件里记的原版哈希，其次最新的那一份。</summary>
    private static string PickBackup(string target)
    {
        string state = StatePath(target);
        if (File.Exists(state))
        {
            try
            {
                foreach (string line in File.ReadAllLines(state))
                {
                    if (!line.StartsWith("orig=")) continue;
                    string bak = BakPathFor(target, line.Substring(5).Trim());
                    if (File.Exists(bak)) return bak;
                }
            }
            catch { }
        }
        string dir = Path.GetDirectoryName(target);
        string pat = Path.GetFileName(target) + BakSuffix + ".*";
        string best = null;
        DateTime bestTime = DateTime.MinValue;
        try
        {
            foreach (string f in Directory.GetFiles(dir, pat))
            {
                DateTime t = File.GetLastWriteTimeUtc(f);
                if (t > bestTime) { bestTime = t; best = f; }
            }
        }
        catch { }
        string legacy = target + BakSuffix;
        if (best == null && File.Exists(legacy)) return legacy;
        return best;
    }


    /// <summary>补丁 3：把那条“为遵守相关法律法规…”的 #US 字符串就地改写为操作指引。
    /// 该槽位 39 字符，只改内容、长度不变，因此不需要动任何堆结构或 IL。</summary>
    private static void TryRewriteNotice(byte[] data, Plan p)
    {
        string want = "导入整合包：请把 .mrpack 文件拖进 PCL 窗口";
        if (want.Length > 39) want = want.Substring(0, 39);
        int heapOff = p.NoticeTok & 0xFFFFFF;
        try
        {
            var m = new Meta(data);
            int pos = m.UsOff + heapOff;
            int pref = data[pos];
            if ((pref & 0x80) != 0) return;           // 只处理单字节长度前缀
            int total = pref;                          // 含终止符
            int charBytes = total - 1;
            string cur = Encoding.Unicode.GetString(data, pos + 1, charBytes);
            if (!cur.Contains("为遵守相关法律法规")) return;   // 不是那条，别乱改
            byte[] nb = Encoding.Unicode.GetBytes(want);
            if (nb.Length > charBytes) return;         // 放不下就不改
            data[pos] = (byte)(nb.Length + 1);
            Buffer.BlockCopy(nb, 0, data, pos + 1, nb.Length);
            for (int i = nb.Length; i < charBytes; i++) data[pos + 1 + i] = 0;
            data[pos + 1 + charBytes] = 0x01;          // #US 终止标记
        }
        catch { }
    }



    /// <summary>补丁 4：新版把下载页左侧「原版游戏」入口的 Visibility 设成 Collapsed（2），
    /// 并且把默认子页改成 Mod。把这三处 ldc.i4.2 改回 ldc.i4.0 即可恢复。</summary>
    private static bool AnalyzeV4(Meta m, Plan p)
    {
        int t = FindType(m, "PCL.PageDownloadLeft");
        if (t == 0) return false;
        int start = m.TypeMethodStart(t);
        int end = t < m.Rows[0x02] ? m.TypeMethodStart(t + 1) : m.Rows[0x06] + 1;
        for (int i = start; i < end; i++)
        {
            if (m.MethodName(i) != ".ctor") continue;
            int hdr;
            int codeSize = m.MethodBodySize(i, out hdr);
            int off = m.MethodBodyStart(i);
            if (codeSize < 20 || codeSize > 400) continue;
            byte[] b = Slice(m.D, off, codeSize);
            int nHide = 0, nPage = 0;
            for (int k = 0; k + 1 < b.Length; k++)
            {
                if (b[k] == 0x18 && b[k + 1] == 0x6F) nHide++;      // ldc.i4.2 ; callvirt set_Visibility
                if (b[k] == 0x18 && b[k + 1] == 0x7D) nPage++;      // ldc.i4.2 ; stfld PageID
            }
            if (nHide == 0 && nPage == 0) return false;             // 这一版没有隐藏，不需要补丁 4
            if (nHide > 4 || nPage > 2) return false;               // 形态不对，别乱改
            p.Patch4 = true; p.P4Row = i; p.P4Body = off;
            return true;
        }
        return false;
    }

    private static void PatchV4(byte[] data, Plan p)
    {
        var m = new Meta(data);
        int hdr;
        int codeSize = m.MethodBodySize(p.P4Row, out hdr);
        int off = m.MethodBodyStart(p.P4Row);
        for (int k = 0; k + 1 < codeSize; k++)
        {
            if (data[off + k] == 0x18 && (data[off + k + 1] == 0x6F || data[off + k + 1] == 0x7D))
                data[off + k] = 0x16;                                // ldc.i4.2 -> ldc.i4.0（Visible / PageID=0）
        }
    }

    private static bool NoticeStillOriginal(byte[] data, int noticeTok)
    {
        try
        {
            var m = new Meta(data);
            int pos = m.UsOff + (noticeTok & 0xFFFFFF);
            int pref = data[pos];
            if ((pref & 0x80) != 0) return false;
            string cur = Encoding.Unicode.GetString(data, pos + 1, pref - 1);
            return cur.Contains("为遵守相关法律法规");
        }
        catch { return false; }
    }

    private static string Sha(byte[] d)
    {
        using (var s = SHA256.Create())
        {
            var h = s.ComputeHash(d);
            var sb = new StringBuilder(h.Length * 2);
            foreach (byte b in h) sb.Append(b.ToString("X2"));
            return sb.ToString();
        }
    }
    private static void EnsureClosed(string target)
    {
        if (System.Diagnostics.Process.GetProcessesByName("Plain Craft Launcher 2").Length > 0)
            throw new Exception("PCL 正在运行，请先完全退出（含托盘）");
    }
    private static void Banner()
    {
        Console.WriteLine("==========================================================");
        Console.WriteLine("  PCL2FIX  下载/安装功能恢复工具（按结构自动适配，不认版本号）");
        Console.WriteLine("  自动识别：下载页拦截 / 整合包安装拦截");
        Console.WriteLine("==========================================================");
        Console.WriteLine();
    }
    private static void Say(string s) { if (!Silent) Console.WriteLine(s); }
    private static int Pause(int code)
    {
        if (Silent) return code;
        Console.WriteLine();
        Console.WriteLine("按任意键退出…");
        try { Console.ReadKey(true); } catch { }
        return code;
    }
}

